# 天巡地护 - 智能农业前端系统

## 🚀 项目结构

- `index.html`：主页面（整合导航、模块、控制面板等）
- `style.css`：独立样式文件（从 HTML 中抽离）
- `script.js`：交互脚本（移动端菜单、状态切换等）
- `assets/`：图片资源文件夹

## 📦 本地预览（使用 Vite）

1. 安装 Node.js：https://nodejs.org/
2. 安装依赖：
   ```
   npm install
   ```
3. 本地运行：
   ```
   npm run dev
   ```
4. 构建发布版本：
   ```
   npm run build
   ```

## 🌐 推荐部署方式

- [Netlify](https://app.netlify.com/)
- [Vercel](https://vercel.com/)
- GitHub Pages

构建后将 `dist/` 上传即可。

---
版权所有 © 2025 天巡地护项目组
